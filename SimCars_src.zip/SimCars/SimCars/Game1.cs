using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace SimCars
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        GraphicsDevice device;
        SpriteBatch spriteBatch;

        Car car;
        Stuff mesh;

        SpriteFont font;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";            
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            graphics.PreferredBackBufferWidth = 640;
            graphics.PreferredBackBufferHeight = 480;
            graphics.PreferMultiSampling=true;   
            
            graphics.ApplyChanges();

            device = graphics.GraphicsDevice;
            Stuff.device = device;
            Stuff.Content = this.Content;

            font = Content.Load<SpriteFont>("arial");
            Car.font = font;

            car = new Car();
            car.LoadModel("nissan-fairlady");
            car.topSpeeds = new float[7] { 0.0f, 12.7325f, 19.4747f, 27.3806f, 36.18f, 45.0687f, 61.1933f };
            car.accelerations = new float[7] { -3.1133f, 4.9133f, 3.5733f, 2.68f, 2.2333f, 1.7867f, 1.34f };
            car.maxReverseSpeed = 9.7222f;
            car.VD = 2.66f;
            car.HD = 1.58f;
            car.L = 1.419f;

            mesh = new Stuff();
            mesh.LoadModel("mesh");
            
            // TODO: use this.Content to load your game content here
        }
                
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        private void ProcessKeyboard(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();

            car.ProcessKeyboard(gameTime);
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {                      
            ProcessKeyboard(gameTime);
            
            car.UpdateCamera();

            car.Update(gameTime);

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            device.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.DarkSlateBlue, 1.0f, 0);

            //TODO: Add your drawing code here
            //spriteBatch.Begin();
            //car.DrawInfo(spriteBatch);
            //spriteBatch.End();
            
            device.RenderState.FillMode = FillMode.Solid;
            car.Draw();          

            device.RenderState.FillMode = FillMode.WireFrame;
            mesh.Draw();            

            base.Draw(gameTime);
        }
    }
}
